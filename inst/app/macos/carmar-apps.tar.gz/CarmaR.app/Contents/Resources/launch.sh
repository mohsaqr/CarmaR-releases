#!/bin/sh
# CarmaR launcher — starts an independent local R kernel, opens the note.
#
# Called by the applet and the menu helper:
#   launch.sh                 plain launch: REJOIN the newest running session,
#                             or start one when none is running
#   launch.sh --new           explicitly start another independent session
#   launch.sh --doc <path>    Finder opened a document: kernel up, then the
#                             kernel's /open door imports it into a notebook
#   launch.sh --listen        headless kernel on the fixed published port, no
#                             notebook tab — the menu's Listen for Web Pages
#
set -u

doc=""
published=""
new=""
listen=""
[ "${1:-}" = "--doc" ] && doc="${2:-}"
[ "${1:-}" = "--published" ] && published="${2:-}"
[ "${1:-}" = "--new" ] && new=1
[ "${1:-}" = "--listen" ] && listen=1

res="$(cd "$(dirname "$0")" && pwd)"
# Overridable for tests (a scratch kernel must never touch the real session's
# url/pid files) and for parallel installs.
state="${CARMAR_STATE:-$HOME/Library/Application Support/CarmaR}"
tag="$(date +%s)-$$"
log="$state/kernel-$tag.log"
mkdir -p "$state"

alert() { osascript -e "display alert \"CarmaR\" message \"$1\"" >/dev/null 2>&1 || echo "$1"; }

# One rolling line per gesture, so "why did a second R appear?" is answerable
# after the fact. The per-launch logs record only the {"url":...} the
# supervisor announced — they cannot distinguish a document open that should
# have rejoined from a New Session that was meant to start one, which is
# exactly the question that comes up. Bounded to the last 500 lines.
trace() {
  printf '%s  %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$state/launches.log" 2>/dev/null || true
  if [ -f "$state/launches.log" ]; then
    tail -500 "$state/launches.log" > "$state/launches.log.tmp" 2>/dev/null \
      && mv "$state/launches.log.tmp" "$state/launches.log" 2>/dev/null || true
  fi
}
trace "gesture: ${1:-plain-launch} ${2:-}"

# Every launch writes three files here (kernel-<tag>.log, pid-<tag>,
# url-<tag>) and nothing ever removed them: 269 files had accumulated on the
# development machine, one triple per launch since the app was first built.
# They are diagnostics for the CURRENT session, so keep a few days of them and
# drop the rest. Failures are ignored on purpose — a launcher must not refuse
# to start a notebook because it could not tidy a log.
find "$state" -maxdepth 1 -type f \
  \( -name 'kernel-*.log' -o -name 'pid-*' -o -name 'url-*' \) \
  -mtime +3 -delete 2>/dev/null || true

# The Paperpile-style helper, self-installed on launch: a LaunchAgent that
# runs update.sh once a day (a ~500 KB download when there is one; silence
# otherwise). Self-installing means the .pkg needs no postinstall script and
# a drag-to-Applications copy gets the same treatment. Idempotent, and
# re-written whenever the app has moved so the agent never points at a ghost.
# Uninstall: launchctl bootout gui/$(id -u)/me.saqr.carmar.update and delete
# the plist — documented in the README.
if [ -z "${CARMAR_NO_AGENT:-}" ] && [ -f "$res/update.sh" ]; then
  agent="$HOME/Library/LaunchAgents/me.saqr.carmar.update.plist"
  if [ ! -f "$agent" ] || ! grep -q "$res/update.sh" "$agent" 2>/dev/null; then
    mkdir -p "$HOME/Library/LaunchAgents"
    cat > "$agent" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>me.saqr.carmar.update</string>
  <key>ProgramArguments</key><array>
    <string>/bin/sh</string><string>$res/update.sh</string>
  </array>
  <key>StartCalendarInterval</key><dict>
    <key>Hour</key><integer>11</integer><key>Minute</key><integer>17</integer>
  </dict>
  <key>RunAtLoad</key><false/>
</dict></plist>
PLIST
    launchctl bootout "gui/$(id -u)/me.saqr.carmar.update" 2>/dev/null || true
    launchctl bootstrap "gui/$(id -u)" "$agent" 2>/dev/null \
      || launchctl load "$agent" 2>/dev/null || true
  fi
fi

RS="${CARMAR_RSCRIPT:-/Library/Frameworks/R.framework/Versions/Current/Resources/bin/Rscript}"
[ -x "$RS" ] || RS="$(command -v Rscript || true)"
if [ -z "${RS:-}" ]; then
  alert "R was not found. Install R from cran.r-project.org, then open CarmaR again."
  exit 1
fi

# A custom-protocol URL is data, never shell. Decode and validate its two
# fields with base R. The origin has no path or credentials; the port is the
# fixed loopback port the published page will probe.
published_origin=""
published_port="4747"
if [ -n "$published" ]; then
  parsed="$("$RS" -e '
    x <- commandArgs(TRUE)[1]
    if (!grepl("^carmar://connect[?]", x)) quit(status=2)
    q <- sub("^[^?]*[?]", "", x)
    fields <- strsplit(q, "&", fixed=TRUE)[[1]]
    get <- function(n) {
      hit <- fields[startsWith(fields, paste0(n, "="))]
      if (!length(hit)) "" else utils::URLdecode(sub("^[^=]*=", "", hit[1]))
    }
    origin <- get("origin"); port <- suppressWarnings(as.integer(get("port")))
    if (!grepl("^https?://[A-Za-z0-9._~-]+(:[0-9]{1,5})?$", origin) ||
        is.na(port) || port < 1L || port > 65535L) quit(status=2)
    cat(origin, "\n", port, "\n", sep="")
  ' "$published" 2>/dev/null)" || exit 2
  published_origin="$(printf '%s\n' "$parsed" | sed -n '1p')"
  published_port="$(printf '%s\n' "$parsed" | sed -n '2p')"
fi

# The destination is always the versioned HTML file. Kernel selection and an
# optional document-open request live in the fragment; localhost stays hidden.
goto() {
  page="$1"
  if [ -n "$doc" ]; then
    enc="$("$RS" -e 'cat(utils::URLencode(commandArgs(TRUE)[1], reserved=TRUE))' "$doc" 2>/dev/null)"
    [ -n "$enc" ] && page="$page&open=$enc"
  fi
  [ -z "${CARMAR_NO_OPEN:-}" ] && open "$page"
}

# Count every health-checked CarmaR session, whichever launcher started it.
# serve.R and the MCP bridge share this same-user runtime registry.
live=0
latest=""
latest_url=""
latest_started=""
uncertain=""
uncertain_started=""
runtime="${CARMAR_RUNTIME_DIR:-$HOME/.carmar/run}"
mkdir -p "$runtime"
for rf in "$runtime"/kernel-*.json; do
  [ -f "$rf" ] || continue
  url="$(sed -n 's/.*"url":"\([^"]*\)".*/\1/p' "$rf" 2>/dev/null)"
  page="$(sed -n 's/.*"file":"\([^"]*\)".*/\1/p' "$rf" 2>/dev/null)"
  pid="$(sed -n 's/.*"pid":[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$rf" 2>/dev/null)"
  started="$(sed -n 's/.*"started":"\([^"]*\)".*/\1/p' "$rf" 2>/dev/null)"
  base="${url%%/\?token=*}"
  health="${base%/}/health"
  if [ -n "$url" ] && curl -fs --max-time 2 "$health" >/dev/null 2>&1; then
    live=$((live+1))
    # The session to rejoin is the newest one. ISO-8601 stamps sort as text.
    if [ -z "$latest" ] || [ "$started" \> "$latest_started" ]; then
      latest="${page:-$url}"
      latest_url="$base"
      latest_started="$started"
    fi
  elif [ -n "$page" ] && [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    # A busy or slow supervisor can miss a two-second /health deadline while
    # still being the session this launch should rejoin. Its own live PID and
    # runtime record are enough to FAIL SAFE: opening its existing notebook
    # may briefly show R as reconnecting; starting a second R session would be
    # invisible and cannot be undone by closing that page.
    if [ -z "$uncertain" ] || [ "$started" \> "$uncertain_started" ]; then
      uncertain="$page"
      uncertain_started="$started"
    fi
  else
    rm -f "$rf"
  fi
done

# Opening CarmaR while a session is already running REJOINS that session
# instead of silently stacking another R process behind it. Starting a second
# session is an explicit gesture: the menu's New Session (launch.sh --new).
# A document open and a published-page connect keep their own paths.
if [ -z "$doc" ] && [ -z "$published" ] && [ -z "$new" ] && [ -z "$listen" ] \
   && [ "$live" -gt 0 ] && [ -n "$latest" ]; then
  trace "  -> REJOINED the newest live session ($live live)"
  goto "$latest"
  exit 0
fi
if [ -z "$doc" ] && [ -z "$published" ] && [ -z "$new" ] && [ -z "$listen" ] \
   && [ -n "$uncertain" ]; then
  trace "  -> REJOINED a slow-but-alive session (health missed 2s)"
  goto "$uncertain"
  exit 0
fi

# Opening a document must not cost an R session. Until now it always did:
# the ONLY delivery channel was CARMAR_OPEN_FILE, which serve.R reads once at
# startup, so `--doc` skipped the rejoin above and started a whole supervisor
# + worker + analyzer per file. Four files in a minute were twelve R
# processes on four ports, and the dialog that used to cap it is gone.
#
# The running kernel's /open door takes the same path over loopback and pushes
# it to the page that is already on screen. Only when that fails — no live
# session, or one that will not answer — does this fall through to starting
# one, which is the case the environment channel exists for.
if [ -n "$doc" ] && [ -z "$published" ] && [ -z "$new" ] && [ -z "$listen" ] \
   && [ -n "$latest_url" ]; then
  enc_doc="$("$RS" -e 'cat(utils::URLencode(commandArgs(TRUE)[1], reserved=TRUE))' "$doc" 2>/dev/null)"
  if [ -n "$enc_doc" ] \
     && curl -fsS --max-time 4 "${latest_url%/}/open?file=$enc_doc" >/dev/null 2>&1; then
    # Delivered. Clear $doc so goto() does not also append &open= — the page
    # would then import the same file twice.
    trace "  -> DELIVERED the document to the live kernel at $latest_url"
    doc=""
    goto "$latest"
    exit 0
  fi
fi

# Listen: make sure a kernel is answering where published pages look (the
# fixed port), and open nothing. If anything already serves that port — the
# keep-ready daemon's kernel, or the user's own session — the job is done.
if [ -n "$listen" ]; then
  if curl -fs --max-time 2 "http://127.0.0.1:4747/health" 2>/dev/null | grep -q '"ok":true'; then
    exit 0
  fi
fi


# If the fixed published kernel already exists, authorize this exact origin
# through its native-only control endpoint and return. No notebook tab, helper
# window or second R process is opened.
if [ -n "$published_origin" ]; then
  encoded_origin="$("$RS" -e 'cat(utils::URLencode(commandArgs(TRUE)[1], reserved=TRUE))' "$published_origin" 2>/dev/null)"
  if curl -fsS --max-time 2 "http://127.0.0.1:$published_port/published/authorize?origin=$encoded_origin" >/dev/null 2>&1; then
    exit 0
  fi
  # A healthy older CarmaR may already own the fixed publishing port but lack
  # the direct-origin endpoint. Replace only a response that identifies itself
  # as a live CarmaR worker; an unrelated program on the port is never touched.
  old_health="$(curl -fsS --max-time 2 "http://127.0.0.1:$published_port/health" 2>/dev/null || true)"
  case "$old_health" in
    *'"ok":true'*'"worker":true'*)
      curl -fsS --max-time 2 "http://127.0.0.1:$published_port/shutdown" >/dev/null 2>&1 || true
      stale_wait=0
      while [ "$stale_wait" -lt 50 ]; do
        curl -fsS --max-time 1 "http://127.0.0.1:$published_port/health" >/dev/null 2>&1 || break
        stale_wait=$((stale_wait+1))
        sleep 0.1
      done
      ;;
  esac
fi

port="${published_port:-4747}"
while grep -qs "\"port\":$port" "$runtime"/kernel-*.json 2>/dev/null; do
  # Published pages and Listen target the FIXED port; a dead record there is
  # overwritten by the kernel that takes the port, never scanned past.
  if [ -n "$published_origin" ] || [ -n "$listen" ]; then break; fi
  port=$((port+1))
done

# First run only: the three supervisor packages.
"$RS" -e 'need <- setdiff(c("httpuv","jsonlite","processx"), rownames(installed.packages())); if (length(need)) install.packages(need, repos="https://cloud.r-project.org")' >>"$log" 2>&1

: > "$log"
# The document rides in the ENVIRONMENT, not only the page URL: macOS `open`
# strips the #fragment from file:// URLs, so `&open=` can silently vanish
# between here and the browser. The page asks the kernel (open-request) when
# its URL arrives bare.
trace "  -> STARTING a new supervisor on port $port (live sessions: $live)"
CARMAR_PORT="$port" CARMAR_PUBLISHED_ORIGIN="$published_origin" \
  CARMAR_LISTEN="${listen:+1}" CARMAR_OPEN_FILE="$doc" \
  nohup "$RS" "$res/kernel/serve.R" >>"$log" 2>&1 &
echo $! > "$state/pid-$tag"

# serve.R announces {"url": ...} on stdout; keep it for session discovery. The
# WHOLE log is scanned, not just line 1 — an R warning ahead of the
# announcement once made the app look like it had failed to start.
i=0
while [ $i -lt 120 ]; do
  url="$(sed -n 's/.*"url":"\([^"]*\)".*/\1/p' "$log" 2>/dev/null | head -1)"
  if [ -n "$url" ]; then
    page="$(sed -n 's/.*"file":"\([^"]*\)".*/\1/p' "$log" 2>/dev/null | head -1)"
    echo "$url" > "$state/url-$tag"
    [ -n "$published_origin" ] && exit 0
    [ -n "$listen" ] && exit 0
    goto "${page:-$url}"
    exit 0
  fi
  sleep 0.5
  i=$((i+1))
done
alert "CarmaR could not start. The log is at $log"
exit 1
