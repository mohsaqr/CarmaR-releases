#!/bin/sh
# CarmaR silent updater — the whole background service.
#
# Runs from a LaunchAgent once a day. An update to CarmaR is ONE html file:
# serve.R serves the highest carmar_V*.html it can see, so updating is
# "download the newer file into Resources/dist/ and stop". No restart, no
# installer, no migration — the next reload of the notebook tab IS the new
# version. The kernel R files ride app releases (the .pkg), which is fine:
# they change an order of magnitude less often than the notebook.
#
# Silent by design: no network, no release repo, an unwritable bundle — every
# failure is a quiet exit, because a background helper that nags is malware
# with better branding. The log tells the story to anyone who asks.
set -u

res="$(cd "$(dirname "$0")" && pwd)"
state="${CARMAR_STATE:-$HOME/Library/Application Support/CarmaR}"
log="$state/update.log"
feed="${CARMAR_FEED:-https://api.github.com/repos/mohsaqr/CarmaR-releases/releases/latest}"
mkdir -p "$state" "$res/dist" 2>/dev/null || exit 0
[ -w "$res/dist" ] || exit 0

say() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$log"; }

json="$(curl -fs --max-time 20 "$feed" 2>/dev/null)" || { say "feed unreachable"; exit 0; }

# The newest carmar_V*.html asset in the release (name and URL).
name="$(printf '%s' "$json" | sed -n 's/.*"name":[ ]*"\(carmar_V[0-9.]*\.html\)".*/\1/p' | sort | tail -1)"
[ -n "$name" ] || { say "no notebook asset in feed"; exit 0; }
url="$(printf '%s' "$json" | tr ',' '\n' | sed -n "s/.*\"browser_download_url\":[ ]*\"\([^\"]*$name\)\".*/\1/p" | head -1)"
[ -n "$url" ] || { say "asset $name has no download url"; exit 0; }

# The best version already on disk, bundle and dist both.
have="$( (ls "$res"/carmar_V*.html "$res"/dist/carmar_V*.html 2>/dev/null || true) | sed 's/.*carmar_V//; s/\.html//' | sort | tail -1)"
want="$(printf '%s' "$name" | sed 's/carmar_V//; s/\.html//')"

RS="/Library/Frameworks/R.framework/Versions/Current/Resources/bin/Rscript"
[ -x "$RS" ] || RS="$(command -v Rscript || true)"
newer=0
if [ -n "${RS:-}" ] && [ -n "$have" ]; then
  # compareVersion understands 0.9 < 0.12 — lexicographic sort does not.
  newer="$("$RS" -e 'cat(as.integer(utils::compareVersion(commandArgs(TRUE)[1], commandArgs(TRUE)[2]) > 0))' "$want" "$have" 2>/dev/null || echo 0)"
elif [ -z "$have" ]; then
  newer=1
fi
[ "$newer" = "1" ] || { say "up to date ($have)"; exit 0; }

tmpfile="$res/dist/.$name.part"
if curl -fsL --max-time 120 -o "$tmpfile" "$url" 2>/dev/null && [ -s "$tmpfile" ] \
   && head -c 512 "$tmpfile" | grep -qi "<!doctype html\|<html"; then
  mv -f "$tmpfile" "$res/dist/$name"
  say "updated to $name"
else
  rm -f "$tmpfile"
  say "download of $name failed"
fi
exit 0
