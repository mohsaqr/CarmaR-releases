#!/bin/sh
# helper-sessions.sh — what CarmaR kernels are answering right now, as TSV.
#
# This is the menu's single discovery implementation. It exists so the native
# helper can render a live session list without embedding discovery logic in
# native UI code, where this repo cannot test it. The rule the whole helper rests on is
# here: a runtime record is a CLAIM, never authority. `serve.R` writes
# ~/.carmar/run/kernel-<port>.json when it starts and removes it on a clean
# stop, but a SIGKILL, a crash or a hard reboot leaves the file behind — so
# every record is health-checked before it is reported, exactly as
# tools/mcp/carmar-mcp.mjs and tools/r-pkg/R/run.R already do.
#
#   sh helper-sessions.sh          → port \t url \t file   (one line each)
#   sh helper-sessions.sh --ports  → ports only, space-separated, one line
#
# Silent and exit 0 when nothing is running: "no sessions" is an ordinary
# state for this notebook, not an error (a notebook opened from a file needs
# no kernel at all).
set -u

dir="${CARMAR_RUNTIME_DIR:-$HOME/.carmar/run}"
timeout="${CARMAR_HEALTH_TIMEOUT:-2}"

alive() {  # port → 0 when a CarmaR kernel answers there
  curl -s -m "$timeout" "http://127.0.0.1:$1/health" 2>/dev/null \
    | grep -q '"ok":true'
}

# jq is not assumable on a reader's Mac, and the records are written by
# jsonlite with no nesting — a field read is a bounded sed, not a parser.
field() {  # file key → value ("" when absent)
  sed -n "s/.*\"$2\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" "$1" | head -1
}

ports=""
[ -d "$dir" ] || { [ "${1:-}" = "--ports" ] && echo ""; exit 0; }

for f in "$dir"/kernel-*.json; do
  [ -e "$f" ] || continue
  port="$(basename "$f" | sed 's/^kernel-//; s/\.json$//')"
  case "$port" in (*[!0-9]*|"") continue ;; esac
  alive "$port" || continue
  ports="$ports $port"
  [ "${1:-}" = "--ports" ] && continue
  url="$(field "$f" url)"
  file="$(field "$f" file)"
  printf '%s\t%s\t%s\n' "$port" "$url" "$file"
done

[ "${1:-}" = "--ports" ] && echo "${ports# }"
exit 0
