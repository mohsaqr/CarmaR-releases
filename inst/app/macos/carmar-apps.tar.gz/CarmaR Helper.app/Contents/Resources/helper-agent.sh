#!/bin/sh
# helper-agent.sh — install, remove or report the always-on CarmaR helper.
#
# ADDITIVE and EXPLICIT. The daily updater (me.saqr.carmar.update) installs
# itself on every app launch because an update nobody asked for is still an
# update nobody notices. A resident R process is different: it is the user's
# memory and the user's login items, so it is installed only when asked, under
# its OWN label, and this script never reads or writes the updater's plist.
#
#   sh helper-agent.sh install     load it, and load it at every login
#   sh helper-agent.sh uninstall   stop it and forget it (kernel stopped too)
#   sh helper-agent.sh status      "installed"/"not installed", plus running
#
# Uninstall is the whole of uninstall: bootout, remove the plist, and the
# managed kernel goes down with the daemon that owns it (helper-daemon.sh
# traps TERM). Nothing is left in LaunchAgents to point at a ghost.
set -u

label="${CARMAR_HELPER_LABEL:-me.saqr.carmar.helper}"
plist="$HOME/Library/LaunchAgents/$label.plist"
state="${CARMAR_STATE:-$HOME/Library/Application Support/CarmaR}"
here="$(cd "$(dirname "$0")" && pwd)"
daemon="$here/helper-daemon.sh"
domain="gui/$(id -u)"

usage() { echo "usage: helper-agent.sh install|uninstall|status" >&2; exit 2; }
[ $# -ge 1 ] || usage

running() { launchctl print "$domain/$label" >/dev/null 2>&1; }

case "$1" in
install)
  [ -f "$daemon" ] || { echo "helper-daemon.sh is missing beside this script." >&2; exit 1; }
  mkdir -p "$HOME/Library/LaunchAgents" "$state"
  # KeepAlive with a throttle, not RunAtLoad alone: the daemon is meant to be
  # the thing that is always there, and a crash at 03:00 must not mean no
  # kernel at 09:00. ThrottleInterval keeps a daemon that cannot start (no R,
  # a bad path) from becoming a spin loop — launchd's own default of 10s is
  # too eager for something that shells out to R.
  cat > "$plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$label</string>
  <key>ProgramArguments</key><array>
    <string>/bin/sh</string><string>$daemon</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>30</integer>
  <key>ProcessType</key><string>Background</string>
  <key>StandardOutPath</key><string>$state/helper-agent.log</string>
  <key>StandardErrorPath</key><string>$state/helper-agent.log</string>
$(if [ -n "${CARMAR_HELPER_PORT:-}${CARMAR_KERNEL_DIR:-}${CARMAR_STATE:-}${CARMAR_RUNTIME_DIR:-}" ]; then
    echo "  <key>EnvironmentVariables</key><dict>"
    [ -n "${CARMAR_HELPER_PORT:-}" ] && echo "    <key>CARMAR_HELPER_PORT</key><string>$CARMAR_HELPER_PORT</string>"
    [ -n "${CARMAR_KERNEL_DIR:-}" ] && echo "    <key>CARMAR_KERNEL_DIR</key><string>$CARMAR_KERNEL_DIR</string>"
    [ -n "${CARMAR_STATE:-}" ] && echo "    <key>CARMAR_STATE</key><string>$CARMAR_STATE</string>"
    [ -n "${CARMAR_RUNTIME_DIR:-}" ] && echo "    <key>CARMAR_RUNTIME_DIR</key><string>$CARMAR_RUNTIME_DIR</string>"
    echo "  </dict>"
  fi)
</dict></plist>
PLIST
  launchctl bootout "$domain/$label" 2>/dev/null || true
  launchctl bootstrap "$domain" "$plist" 2>/dev/null || launchctl load "$plist" 2>/dev/null || true
  echo "installed"
  ;;
uninstall)
  launchctl bootout "$domain/$label" 2>/dev/null || launchctl unload "$plist" 2>/dev/null || true
  rm -f "$plist"
  echo "uninstalled"
  ;;
status)
  if [ -f "$plist" ]; then printf 'installed'; else printf 'not installed'; fi
  if running; then echo " (running)"; else echo ""; fi
  ;;
*) usage ;;
esac
