# CarmaR macOS runtime preflight and managed provisioning.
#
# With no arguments this is called by launch.sh immediately before a new
# supervisor starts. Personal installations retain the convenient first-run
# package repair. A managed installation never falls back to public CRAN:
# Finder does not inherit MDM environment variables and the managed JSON file
# itself needs jsonlite, so trying to read policy before jsonlite exists would
# create a circular and unsafe bootstrap.
#
# Administrators run the same, signed app resource in provisioning mode:
#   Rscript --vanilla runtime-preflight.R --provision \
#     --repository https://packages.example.org/cran/latest \
#     --evidence /var/log/carmar-runtime.json
# A file:/// absolute mini-CRAN repository is accepted for offline deployment.

CARMAR_RUNTIME_SCHEMA <- "carmar-macos-runtime-v1"
CARMAR_RUNTIME_PACKAGES <- c("httpuv", "jsonlite", "processx")
CARMAR_RUNTIME_DEFAULT_REPOSITORY <- "https://cloud.r-project.org"
CARMAR_RUNTIME_MANAGED_PATH <-
  "/Library/Application Support/CarmaR/managed-settings.json"

carmar_runtime_env <- function(env, name) {
  trimws(env(name, ""))
}

carmar_runtime_is_managed <- function(
    env = Sys.getenv,
    file_exists = file.exists,
    sysname = Sys.info()[["sysname"]]) {
  explicit <- carmar_runtime_env(env, "CARMAR_MANAGED_CONFIG")
  update_managed <- tolower(carmar_runtime_env(env, "CARMAR_UPDATE_MANAGED"))
  nzchar(explicit) || update_managed %in% c("1", "true", "yes", "on") ||
    (identical(sysname, "Darwin") && file_exists(CARMAR_RUNTIME_MANAGED_PATH))
}

carmar_runtime_repository <- function(value, require_explicit = FALSE,
                                      directory_exists = dir.exists) {
  repository <- trimws(as.character(value %||% ""))
  if (!nzchar(repository)) {
    if (isTRUE(require_explicit)) {
      stop("Provisioning requires --repository with an approved HTTPS or file:/// mini-CRAN source.",
           call. = FALSE)
    }
    repository <- CARMAR_RUNTIME_DEFAULT_REPOSITORY
  }
  if (length(repository) != 1L || is.na(repository) ||
      grepl("[\r\n\t]", repository) || grepl("[?#]", repository)) {
    stop("The R package repository must be one query-free, single-line URL.",
         call. = FALSE)
  }
  if (startsWith(repository, "https://")) {
    authority <- sub("^https://([^/]+).*$", "\\1", repository)
    if (!grepl("^[A-Za-z0-9.-]+(:[0-9]{1,5})?$", authority) ||
        grepl("@", authority, fixed = TRUE)) {
      stop("The HTTPS package repository has an invalid or credential-bearing host.",
           call. = FALSE)
    }
    return(list(url = repository, kind = "https"))
  }
  if (startsWith(repository, "file:///")) {
    local_path <- utils::URLdecode(sub("^file://", "", repository))
    if (!startsWith(local_path, "/") || !directory_exists(local_path)) {
      stop("The file:/// package repository must name an existing absolute directory.",
           call. = FALSE)
    }
    return(list(url = repository, kind = "offline"))
  }
  stop("Only HTTPS and file:/// package repositories are allowed.", call. = FALSE)
}

`%||%` <- function(value, fallback) {
  if (is.null(value) || !length(value)) fallback else value
}

carmar_runtime_missing <- function(
    packages = CARMAR_RUNTIME_PACKAGES,
    available = function(package) requireNamespace(package, quietly = TRUE)) {
  packages[!vapply(packages, available, logical(1))]
}

carmar_runtime_preflight <- function(
    env = Sys.getenv,
    file_exists = file.exists,
    sysname = Sys.info()[["sysname"]],
    available = function(package) requireNamespace(package, quietly = TRUE),
    installer = function(packages, repository) {
      utils::install.packages(packages, repos = c(CRAN = repository),
                              dependencies = c("Depends", "Imports", "LinkingTo"))
    }) {
  missing <- carmar_runtime_missing(available = available)
  if (!length(missing)) return(invisible(list(installed = character(), repository = "none")))

  if (carmar_runtime_is_managed(env, file_exists, sysname)) {
    stop(paste0(
      "This managed CarmaR installation is missing required R packages: ",
      paste(missing, collapse = ", "),
      ". Ask IT to run the signed CarmaR runtime provisioning policy. ",
      "No public package repository was contacted."), call. = FALSE)
  }

  selected <- carmar_runtime_repository(carmar_runtime_env(env, "CARMAR_CRAN_MIRROR"))
  message("CarmaR is preparing this R installation: ",
          paste(missing, collapse = ", "), " ...")
  installer(missing, selected$url)
  remaining <- carmar_runtime_missing(available = available)
  if (length(remaining)) {
    stop("CarmaR could not install required R packages: ",
         paste(remaining, collapse = ", "), ".", call. = FALSE)
  }
  invisible(list(installed = missing, repository = selected$kind))
}

carmar_runtime_default_library <- function() {
  candidates <- .Library.site[nzchar(.Library.site)]
  if (length(candidates)) candidates[[1L]] else file.path(R.home(), "site-library")
}

carmar_runtime_json_string <- function(value) {
  value <- enc2utf8(as.character(value))
  value <- gsub("\\\\", "\\\\\\\\", value)
  value <- gsub('"', '\\\\"', value, fixed = TRUE)
  value <- gsub("\r", "\\\\r", value, fixed = TRUE)
  value <- gsub("\n", "\\\\n", value, fixed = TRUE)
  paste0('"', value, '"')
}

carmar_runtime_evidence <- function(versions, repository_kind) {
  entries <- paste0("    ", carmar_runtime_json_string(names(versions)), ": ",
                    carmar_runtime_json_string(unname(versions)))
  paste(c(
    "{",
    paste0('  "schema": ', carmar_runtime_json_string(CARMAR_RUNTIME_SCHEMA), ","),
    '  "status": "passed",',
    paste0('  "rVersion": ', carmar_runtime_json_string(as.character(getRversion())), ","),
    paste0('  "repositoryKind": ', carmar_runtime_json_string(repository_kind), ","),
    '  "libraryKind": "administrator-site",',
    '  "packages": {',
    paste(entries, collapse = ",\n"),
    "  }",
    "}"
  ), collapse = "\n")
}

carmar_runtime_write_atomic <- function(path, text) {
  destination <- normalizePath(path, mustWork = FALSE)
  parent <- dirname(destination)
  if (!dir.exists(parent)) dir.create(parent, recursive = TRUE, mode = "0755")
  temporary <- paste0(destination, ".part.", Sys.getpid())
  on.exit(unlink(temporary), add = TRUE)
  writeLines(text, temporary, useBytes = TRUE)
  Sys.chmod(temporary, mode = "0600")
  if (!file.rename(temporary, destination)) {
    stop("Could not publish the runtime evidence file atomically.", call. = FALSE)
  }
  invisible(destination)
}

carmar_runtime_provision <- function(
    repository,
    library = carmar_runtime_default_library(),
    evidence = "",
    directory_exists = dir.exists,
    directory_create = function(path) dir.create(path, recursive = TRUE, mode = "0755"),
    is_symlink = function(path) nzchar(Sys.readlink(path)),
    installed = function(path) utils::installed.packages(lib.loc = path),
    installer = function(packages, repository, library) {
      utils::install.packages(packages, repos = c(CRAN = repository), lib = library,
                              dependencies = c("Depends", "Imports", "LinkingTo"))
    },
    evidence_writer = carmar_runtime_write_atomic) {
  selected <- carmar_runtime_repository(repository, require_explicit = TRUE,
                                        directory_exists = directory_exists)
  library <- path.expand(trimws(as.character(library %||% "")))
  if (length(library) != 1L || !nzchar(library) || !startsWith(library, "/") ||
      grepl("[\r\n\t]", library)) {
    stop("The administrator package library must be one absolute path.", call. = FALSE)
  }
  if (directory_exists(library) && is_symlink(library)) {
    stop("The administrator package library may not be a symlink.", call. = FALSE)
  }
  if (!directory_exists(library)) directory_create(library)
  if (!directory_exists(library) || file.access(library, 2L) != 0L) {
    stop("The administrator package library is not writable; run provisioning as root.",
         call. = FALSE)
  }

  table <- installed(library)
  present <- if (is.null(dim(table))) character() else rownames(table)
  missing <- setdiff(CARMAR_RUNTIME_PACKAGES, present)
  if (length(missing)) installer(missing, selected$url, library)

  table <- installed(library)
  present <- if (is.null(dim(table))) character() else rownames(table)
  remaining <- setdiff(CARMAR_RUNTIME_PACKAGES, present)
  if (length(remaining)) {
    stop("Runtime provisioning did not install: ", paste(remaining, collapse = ", "),
         ".", call. = FALSE)
  }
  versions <- setNames(as.character(table[CARMAR_RUNTIME_PACKAGES, "Version"]),
                       CARMAR_RUNTIME_PACKAGES)
  report <- carmar_runtime_evidence(versions, selected$kind)
  if (nzchar(evidence)) evidence_writer(evidence, report)
  cat(report, "\n", sep = "")
  invisible(list(versions = versions, repository = selected$kind, library = library))
}

carmar_runtime_parse_provision <- function(args) {
  if (!length(args) || !identical(args[[1L]], "--provision")) {
    stop("Expected --provision followed by --name value pairs.", call. = FALSE)
  }
  values <- args[-1L]
  if (length(values) %% 2L) stop("Provisioning arguments must be --name value pairs.", call. = FALSE)
  allowed <- c("repository", "library", "evidence")
  parsed <- list()
  if (length(values)) {
    for (index in seq.int(1L, length(values), by = 2L)) {
      key <- values[[index]]
      if (!startsWith(key, "--")) stop("Provisioning arguments must use --name value pairs.", call. = FALSE)
      key <- substring(key, 3L)
      if (!key %in% allowed || !is.null(parsed[[key]])) {
        stop("Unknown or duplicate provisioning argument: --", key, ".", call. = FALSE)
      }
      parsed[[key]] <- values[[index + 1L]]
    }
  }
  if (is.null(parsed$repository) || !nzchar(parsed$repository)) {
    stop("Provisioning requires --repository.", call. = FALSE)
  }
  parsed
}

carmar_runtime_main <- function(args = commandArgs(TRUE)) {
  tryCatch({
    if (length(args)) {
      parsed <- carmar_runtime_parse_provision(args)
      carmar_runtime_provision(parsed$repository,
        library = parsed$library %||% carmar_runtime_default_library(),
        evidence = parsed$evidence %||% "")
    } else {
      carmar_runtime_preflight()
    }
  }, error = function(error) {
    message("CarmaR runtime preflight failed: ", conditionMessage(error))
    quit(save = "no", status = 20L, runLast = FALSE)
  })
}

if (sys.nframe() == 0L) carmar_runtime_main()
