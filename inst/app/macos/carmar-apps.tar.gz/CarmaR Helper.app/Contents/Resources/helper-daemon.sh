#!/bin/sh
# helper-daemon.sh — the resident half of the CarmaR helper.
#
# OPT-IN: installing the menu app does not enable this daemon. The user enables
# it with Keep a kernel ready. What it adds is one always-ready kernel on the
# fixed port, so opening a notebook or a published page never waits for R.
#
# ── THE TWO RULES ─────────────────────────────────────────────────────────
#
# 1. IT NEVER TAKES A PORT SOMEONE ELSE IS USING. If a kernel already answers
#    on the port — one the user started from R, from the app, or from a
#    published page — the daemon idles and watches. It does not stop it, does
#    not restart it, does not "adopt" it. A helper that killed the session you
#    were working in to install its own would be worse than no helper.
#
# 2. THE KERNEL IT OWNS DOES NOT LINGER (CARMAR_LINGER=0). Idle linger and
#    launchd KeepAlive are the same decision made by two owners: a kernel that
#    stopped itself at ten minutes would be restarted immediately, forever, at
#    whatever the throttle interval is. So exactly one of them decides, and for
#    the managed kernel it is launchd. Ad-hoc sessions keep their ten minutes —
#    that is what stops them accumulating (see spike/serve.R, linger_check).
#
# It evaluates nothing. It starts a supervisor and watches a health endpoint;
# user code lives where it always did, in spike/worker.R behind spike/serve.R.
#
#   sh helper-daemon.sh          run in the foreground (launchd runs it this way)
#   sh helper-daemon.sh --once   one pass, no loop — for tests
set -u

port="${CARMAR_HELPER_PORT:-4747}"
poll="${CARMAR_HELPER_POLL:-15}"
state="${CARMAR_STATE:-$HOME/Library/Application Support/CarmaR}"
log="$state/helper.log"
mkdir -p "$state"

here="$(cd "$(dirname "$0")" && pwd)"
# In the app bundle the kernel sits in Resources/kernel; in the repo it is
# spike/. An explicit override wins, so a test never runs the installed one.
if [ -n "${CARMAR_KERNEL_DIR:-}" ]; then kernel_dir="$CARMAR_KERNEL_DIR"
elif [ -d "$here/kernel" ]; then kernel_dir="$here/kernel"
else kernel_dir="$(cd "$here/../.." && pwd)/spike"; fi

RS="/Library/Frameworks/R.framework/Versions/Current/Resources/bin/Rscript"
[ -x "$RS" ] || RS="$(command -v Rscript || true)"

say() { printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$log"; }

healthy() {
  curl -s -m 2 "http://127.0.0.1:$port/health" 2>/dev/null | grep -q '"ok":true'
}

kernel_pid=""
# Stopping means /shutdown, never a signal: the supervisor takes its worker,
# its runtime record and any running `claude -p` down with it in that order.
# A killed kernel leaves the record behind, which is litter every reader then
# has to health-check around.
stop_kernel() {
  [ -n "$kernel_pid" ] || return 0
  curl -s -m 3 "http://127.0.0.1:$port/shutdown" >/dev/null 2>&1 || true
  sleep 1
  kill -0 "$kernel_pid" 2>/dev/null && kill "$kernel_pid" 2>/dev/null
  kernel_pid=""
}
trap 'say "helper stopping"; stop_kernel; exit 0' TERM INT HUP

if [ -z "${RS:-}" ]; then
  say "no Rscript found — helper idle"
  [ "${1:-}" = "--once" ] && exit 0
fi

say "helper started (port $port, kernel $kernel_dir)"

pass() {
  if healthy; then
    # Someone is serving this port. Ours or theirs, it makes no difference
    # here: the port has a kernel, which is the whole job.
    return 0
  fi
  if [ -z "${RS:-}" ]; then return 0; fi
  say "starting managed kernel on $port"
  CARMAR_PORT="$port" CARMAR_LINGER=0 "$RS" "$kernel_dir/serve.R" >> "$log" 2>&1 &
  kernel_pid=$!
  # Give it the same start window the launcher allows before reporting.
  i=0
  while [ "$i" -lt 60 ]; do
    healthy && { say "managed kernel up (pid $kernel_pid)"; return 0; }
    kill -0 "$kernel_pid" 2>/dev/null || { say "managed kernel exited during start"; kernel_pid=""; return 1; }
    sleep 1
    i=$((i + 1))
  done
  say "managed kernel did not answer in 60s"
  return 1
}

if [ "${1:-}" = "--once" ]; then pass; exit 0; fi

while :; do
  pass || true
  if [ -n "$kernel_pid" ]; then
    # Our own kernel: block on it. When it exits — a crash, a Quit from the
    # notebook, a stop_kernel() from R — the next pass starts a fresh one.
    wait "$kernel_pid" 2>/dev/null || true
    say "managed kernel exited"
    kernel_pid=""
  else
    # Somebody else's kernel, or no R at all: poll, cheaply.
    sleep "$poll"
  fi
done
